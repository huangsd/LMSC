function res=para(para1,para2,para3)
    l1=length(para1);
    l2=length(para2);
    l3=length(para3);
    x=1;
    for i=1:l1
        for j=1:l2
            for k=1:l3
                res(x,:)=[para1(i),para2(j),para3(k)];
                x=x+1;
            end
        end
    end
end