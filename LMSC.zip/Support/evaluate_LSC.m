function [purity,nmi,randindex] = evaluate_LSC(model,Y,tprime,display_flag,display_str)
% evaluate the performance of clustering, if display_flag is true, the result will be displayed

kmtrials = 100;

F=model.E{tprime}*model.D;
for i = 1:length(Y)
    F(i,:) = F(i,:)/norm(F(i,:));
end

pred=kmeans_freq(real(F),model.clusterNum{tprime},kmtrials,'m');

purity   = eval_acc_purity(Y,pred)*100;
% purity =length(find(Y == pred))/length(Y);
nmi     = eval_nmi(Y,pred)*100;
randindex = eval_rand(Y,pred)*100;

if display_flag == true
    disp(display_str);
    disp(['purity:    ' num2str(purity)]);
    disp(['nmi:       ' num2str(nmi)]);
    disp(['randindex: ' num2str(randindex)]);
end
end