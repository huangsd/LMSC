% You should have received a copy of the GNU General Public License
% along with ELLA.  If not, see <http://www.gnu.org/licenses/>.
function model = initModelLSC(options)  %��optionsȡ��ģ�Ͳ���ֵ
    addpath('./externalLibs/spams-matlab/build');
    model = [];
    if ~exist('options','var')
	disp('Must specify model options');
	return; 
    end
    V = options.V;
    d = options.d; %2500
    k = options.k; % 4
    if ~ismember('nei1',fields(options))
        nei1 = 1;
    else
        nei1 = options.nei1;
    end     
    if ~ismember('step',fields(options))
        step = 1;
    else
        step = options.step;
    end
    if ~ismember('lambda1',fields(options))
        lambda1 = 1;
    else
        lambda1 = options.lambda1;
    end
    if ~ismember('lambda2',fields(options))
        lambda2 = 1;
    else
        lambda2 = options.lambda2;
    end
    
    if ~ismember('mu',fields(options))
        mu = 1;
    else
        mu = options.mu;
    end
    if ~ismember('beta',fields(options))
        beta = 1;
    else
        beta = options.beta;
    end
 
    T = 0;
    clusterNum=zeros(T,1); % �������
    E= cell(T,1);
    for v=1:V
     % ����ԭ��Ϣ
    M{v,1} = zeros(k,k);     % statistics variable
    C{v,1}=zeros(d(v),k);       % statistics variable
    B{v,1}=zeros(k,k);       % center library
    F{v,1}=zeros(d(v),k);       % feature library
    Omega{v,1}=zeros(d(v),d(v));   % L21-norm
    alpha(v) = 1/V;
    end
    D = zeros(k,k);     % fusion center library
    model = struct('nei1',nei1,...
           'V',V,...
           'd',d,...
		   'k',k,...		
		   'step',step,...
           'lambda1',lambda1,...
           'lambda2',lambda2,...
		   'mu',mu,...
           'beta',beta,...
      	   'T',T,...
           'E',{E},...
		   'M',{M},...
           'C',{C},...
		   'B',{B},...
		   'F',{F},...
           'Omega',{Omega},...
           'alpha', alpha,...
           'D',D);
end
