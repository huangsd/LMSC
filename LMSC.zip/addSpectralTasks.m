function [model,iter,funcVal] = addSpectralTasks(model,X,taskid,justEncode)


max_iter=200;
model.T = model.T+1;  %任务序号，初始值为0 
n = size(X{1},1);   %样本数量
for v=1:model.V
    d(v) = size(X{v,1},2);
    [A{v,1}] = normalize_matrix(X{v,1} - min(min(X{v,1}))); % A是原文中的X尖
end

options1 = [];
% choose the distance for clustering
options1.NeighborMode = 'KNN';
options1.k = model.nei1;    % 邻居的数量
% options1.WeightMode = 'Binary';
% options1.WeightMode = 'Cosine';
options1.WeightMode = 'HeatKernel';
% options1.prenormalize = 1;
for v=1:model.V
W11{v,1} = constructW(X{v},options1);
W11{v,1}= normalize_matrix(W11{v,1});
W11{v,1} = (W11{v,1} + W11{v,1}')/2;   % 原文中的K 数据的拉普拉斯阵
end
funcVal=[];


%初始化 T==1时的参数   多了一个初始化知识库的操作，B F
if model.T==1
    E = zeros(size(n,model.k));
    for v=1:model.V
        [E_temp{v,1},D1{v,1}] = eigs(W11{v,1},model.k,'LA'); %[ 特征向量，特征值对角阵],解SC
        % calculate a specified number of eigenvalues and eigenvectors
        % "LA"	The k largest (algebraic) eigenvalues, considering any negative sign
        [D1{v,1},index] = sort(diag(D1{v,1}),'descend'); 
        E_temp{v,1} = E_temp{v,1}(:,index);     %特征值排序后 得到谱聚类的最优解 E即是F
        model.B{v,1}=eye(model.k);    %用单位阵初始化B
        model.D =eye(model.k); %初始化
        [U{v,1} S{v,1} V{v,1}] = svds(A{v,1},model.k);    %%%%%%？？？？？V的维度不对
        [s{v,1} index] = sort(diag(S{v,1}),'descend');
        model.F{v,1} = V{v,1}(:,index);        %初始化L
        for i = 1:model.k 
            model.F{v,1}(:,i) = model.F{v,1}(:,i)/norm(model.F{v,1}(:,i));
            t1=E_temp{v,1}(:,i)'*A{v,1}*model.F{v,1}(:,i);
            if t1 < 0
                E_temp{v,1}(:,i) = -E_temp{v,1}(:,i);   %表示E阵的第i列
            end
        end 
        E = E + E_temp{v,1};
    end
        E = E/model.V;
else
    E = zeros(size(n,model.k));
    for v=1:model.V
        [E_temp{v,1},D_W11] = eigs(W11{v,1},model.k,'LA');
        [D_W11,index_W11] = sort(diag(D_W11),'descend');
        E_temp{v,1} = E_temp{v,1}(:,index_W11);
        for i = 1:model.k
            F_temp{v,1} = model.F{v,1}(:,i)/norm(model.F{v,1}(:,i));
            t1=E_temp{v,1}(:,i)'*A{v,1}*F_temp{v,1};
            if t1 < 0
                E_temp{v,1}(:,i) = -E_temp{v,1}(:,i);
            end
        end
        E = E + E_temp{v,1};
    end
    E = E/model.V;
end
for v=1:model.V
    Omega{v,1}=sqrt(sum(model.F{v,1}.*model.F{v,1},2)+eps);
    model.Omega{v,1}=spdiags(Omega{v,1},0,model.d(v),model.d(v));
    % S = spdiags(Bin,d,m,n) 通过获取 Bin 的列并沿 d 指定的对角线放置它们，来创建一个 m×n 稀疏矩阵 S。
end

[f_old,f1,f2,f3,f4] = compute_obj(W11,E,A,model); %相似度矩阵 最优解F X尖  model
funcVal=[funcVal,f_old];

if model.lambda1>0
     for iter=1:max_iter
        if rem(iter,10) == 0    %迭代10次后改变学习率学习率
             %disp(['iter:' num2str(iter) ' obj: ' num2str(f_old)]);
             model.step=model.step*sqrt(1+iter);
             %                     disp(['f: ' num2str(f_old) ' f1: ' num2str(f1) ' f2: ' num2str(f2) ' f3: ' num2str(f3) ' f4: ' num2str(f4)]);
             %                     disp( ' ');
        end
        %更新E             
        [E]  = update_E(W11,E,A,model);      
        %更新B
        for v=1:model.V
            model.M{v,1}=model.M{v,1}+E'*W11{v,1}*E;
            model.C{v,1}=model.C{v,1}+model.lambda1*A{v,1}'*E;
            B_temp{v,1}=model.M{v,1}/model.T+model.B{v,1}*model.F{v,1}'*model.C{v,1}/model.T-model.beta*model.alpha(v)*(2*eye(model.k)-model.B{v,1}*model.D'-model.D*model.B{v,1});
            [model.B{v,1},D_B_temp] = eigs(B_temp{v,1},model.k,'LM');
            [D_B_temp,index_B_temp] = sort(diag(D_B_temp),'descend');
            model.B{v,1}=model.B{v,1}(:,index_B_temp);
        end 
        %更新D
        for v=1:model.V
            D_temp{v,1} = model.alpha(v)*(2*eye(model.k)-model.B{v,1}*model.D'-model.D*model.B{v,1});
        end
            D_sum = zeros(size(D_temp{1,1}));
        for v=1:model.V
            D_sum = D_sum+D_temp{v,1};
        end
        [D,D2] = eigs(D_sum,model.k,'LA');
        [D2,index] = sort(diag(D2),'descend');
        D = D(:,index);
        model.D = D;

        %更新alpha
        for v = 1:model.V
            model.alpha(v) = 1/(2*norm(model.D-model.B{v,1},'fro'));
        end

        %更新Omega
        for v=1:model.V
        Omega{v,1}=sqrt(sum(model.F{v,1}.*model.F{v,1},2)+eps);
        model.Omega{v,1}=spdiags(Omega{v,1},0,model.d(v),model.d(v));
        end
        
        % 更新F
        for v=1:model.V
        F_temp{v,1}=model.C{v,1}*model.B{v,1}+model.mu*model.Omega{v,1}*model.F{v,1};        
        model.F{v,1}=find_projection(F_temp{v,1});
        end
       
       %   [f_current,f1,f2,f3,f4] = compute_obj(W11,W22,F1,F2,F3,A1,A2,r);disp(['iter:' num2str(iter) ' update3 obj: ' num2str(f_current)]);
         
        [f_new,f1,f2,f3,f4] = compute_obj(W11,E,A,model); %f_new should be bigger than f_old
%         if f_new <= f_old
%             error('wrong in TSC');
%         end
        if iter>2
            func_diff = abs(real(f_new) - real(f_old))/real(f_old);
            funcVal=[funcVal,f_new];
            if func_diff < 0.0001
                model.E{taskid}=E;
                break;
            end
        end
        f_old = f_new;
%          iter = iter + 1;
         %         disp(' ');
     end
end
         

% F3 = randn(size(F3));

[f_old ,f1,f2,f3,f4] = compute_obj(W11,E,A,model); % disp(['init;']);
% disp(['f: ' num2str(f) ' f1: ' num2str(f1) ' f2: ' num2str(f2) ' f3: ' num2str(f3) ' f4: ' num2str(f4)]);
% disp(' ');

% f_ideal = compute_ideal_objective(W11,W22,A1,A2,r,F3,Yt,Ys);
model.E{taskid}=E; 

end

function [f,f1,f2,f3,f4] = compute_obj(W11,E,A,model)  %计算loss值
 for v=1:model.V
    f1{v,1} = trace(model.B{v,1}'*E'*W11{v,1}*E*model.B{v,1});
    f2{v,1} = model.lambda1*trace(model.F{v,1}'*A{v,1}'*E*model.B{v,1});
    f3{v,1} = model.mu*trace(model.F{v,1}'*model.Omega{v,1}*model.F{v,1});
    f4{v,1} = model.beta*model.alpha(v)*power(norm(model.D-model.B{v,1},'fro'),2);%F范数
    f_temp(v)= f1{v,1}+f2{v,1}+f3{v,1}-f4{v,1};
 end
 f = sum(f_temp);
% disp(['f1: ' num2str(f1) ' f2: ' num2str(f2) ' f3: ' num2str(f3) ' f4: ' num2str(f4)]);
end


function [E]  = update_E(W11,E,A,model) 
        dE_finall = zeros(size(E));
    for v=1:model.V
        dE_temp{v,1} = 2*W11{v,1}*E*model.B{v,1}*model.B{v,1}' + model.lambda1*A{v,1}*model.F{v,1}*model.B{v,1}';
        dE_finall = dE_finall+ dE_temp{v,1};
    end
        dE_finall = dE_finall/model.V;

        %根据双模态简单融合E的方法
        dE_finall= dE_finall/norm(dE_finall,'fro');
        dE_finall= dE_finall + model.step*dE_finall;
        [E] = find_projection(dE_finall);
    %     E_var=(E+abs(E))/2;
    %     if norm(E-E_var,'fro')<0.0001
    %         break;
    %     end
    % end
    
end

function [Ap] = find_projection(A)
% disp('projection');
[U D V] = svd(A,0);
% Ap = U*eye(size(D))*V';
Ap = U*V';
assert(norm(Ap'*Ap - eye(size(Ap,2)),'fro')<0.000000001,'wrong projection');
end


function [A] = normalize_matrix(A)
[nt ns] = size(A);

D1 = sum(A,2);% sum of column nt*1
D2 = sum(A,1);% 1*ns
D1 = sqrt(D1);
D2 = sqrt(D2);

    for i = 1:nt
        if D1(i)~=0
            A(i,:) = A(i,:)/D1(i);
        end
    end
    for i = 1:ns
        if D2(i) ~=0
            A(:,i) = A(:,i)/D2(i);
        end
    end
end