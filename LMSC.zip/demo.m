clear
close all
clc
addpath './Support'
addpath './Datasets'
addpath './Result'
%===========================================
% This is a demo in 3sources dataset
%===========================================

load('Datasets/3Sources_ours','X','Y');   % 里面有4个任务


%% Begin to train for L2SC
istest = 0;

% para
all_i=[0.001 0.01 0.1 1 10 100];
all_j=[0.001 0.01 0.1 1 10 100];
all_k=[0.001 0.01 0.1 1 10 100];

tic

parameter=para(all_i,all_j,all_k);
parasize=size(parameter,1);
result=zeros(parasize,9);
parfor j=1:parasize
        [Result_avg] = run_main(X, Y, parameter(j,1), parameter(j,2),parameter(j,3), istest);
        result(j,:)=[parameter(j,:),Result_avg'];
    
end

toc

result = result';

[j,k] = size(result);
for i =1:k
  for j=1:(k-i)
      if result(4,j)<result(4,j+1)
          tem = result(:,j);
          result(:,j)=result(:,j+1);
          result(:,j+1)= tem;

      end
   end
end
save('Result/test__.mat','result');

