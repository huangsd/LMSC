% example

function [Result] = run_main(X, Y, lambda1, lambda2,lambda3, test)
% intilization

T=length(X); % T = 4
V = size(X{1,1},1);  % view

X_all= cell(V,1);
count=0;
for t=1:T
    count=[count,count(end)+size(X{1,t}{1,1},1)];
    for i=1:V
        X_all{i,1} = cat(1,X_all{i,1},X{1,t}{i});
    %     X_all=[X_all,X{1,t}];  
    end
end
% 将所有任务的x整合到一个X_all 矩阵中 count记录分界线0 225 475 730 1036
for i=1:V
    X_all{i,1} = my_tfidf(X_all{i,1},1);
% 原特征 计算TF-IDF代替    
end
for v=1:V
    a = sum(X_all{v,1});
    i = (a>0);
    X_all{v,1} = X_all{v,1}(:,i);
end
for t=1:T
    for v=1:V
    X{1,t}{v,1}=X_all{v,1}(count(t)+1:count(t+1),:);     
    end
end

if test==0
    for v=1:V
     d(v)=size(X{1,1}{v,1},2); %2500
     for t=1:T
     B{t}{v,1}=[]; % libray B
     end
    end 
    % lambda1=1;
    % lambda2=1; 

    purity=[];
    nmi=[];
    randindex=[];
    nei = 20; % 邻居
    model = initModelLSC(struct('nei1',nei,...
        'V',V,...  % view 
        'd',d,...
        'k',20,...   % k 正交基矩阵得大小！！！
        'step',0.1,...
        'lambda1',lambda1,... %i
        'mu',lambda2,...   %j
        'beta',lambda3,... %k
        'initializeWithFirstKTasks',true));

    learned = logical(zeros(length(Y),1));  
    % 把数组（矩阵）中的非零数变成1,零还是0
    unlearned = find(~learned);

    for t=1:T
        idx=t;
        model.clusterNum{unlearned(idx)}=max(Y{unlearned(idx)});  %  从Y标签中的最大值找到簇数
        [model,iter,funcVal] = addSpectralTasks(model,X{unlearned(idx)},unlearned(idx),false);    
        D{t}=model.D; %取有用的D
       % learned(unlearned(idx)) = true;
        %unlearned = find(~learned);
    end  

    % evaluate the L2SC
    for tprime=1:T 
        [purity_temp,nmi_temp,randindex_temp]=evaluate_LSC(model,Y{tprime},tprime,true,'Lifelong Spectral Clustering');
        purity=[purity,purity_temp];
        nmi=[nmi,nmi_temp];
        randindex=[randindex,randindex_temp];
    end

    Result=[mean(purity);mean(nmi);mean(randindex);std(purity);std(nmi);std(randindex)];

else
     %% test lifelong learning
     Result{T}=[];
     for t=1:T
         purity=[];
         nmi=[];
         randindex=[];
         for tprime=t:T                                                                                                                                                                                                                                                                                                                                                            
             pred=kmeans_freq(real(F),model.clusterNum{t},kmtrials,'m');
             purity_temp   = eval_acc_purity(Y{t},pred)*100;
             % purity =length(find(Y == pred))/length(Y);
             nmi_temp     = eval_nmi(Y{t},pred)*100;
             randindex_temp = eval_rand(Y{t},pred)*100; 
             purity=[purity,purity_temp];
             nmi=[nmi,nmi_temp];
             randindex=[randindex,randindex_temp];
         end
         Result{t}=[purity;nmi;randindex];
     end
end
end
 
 
